# IPSA Power System MCP Server - Uninstall Script
# Run this to remove the server from Claude Desktop
# Right-click this file and select "Run with PowerShell"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  IPSA MCP Server Uninstall" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# ── Step 1: Remove entry from Claude Desktop config ───────────
Write-Host "[1/2] Removing from Claude Desktop config..." -ForegroundColor Yellow

$configPaths = @(
    "$env:LOCALAPPDATA\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Roaming\Claude\claude_desktop_config.json",
    "$env:APPDATA\Claude\claude_desktop_config.json"
)

$configPath = $null
foreach ($cp in $configPaths) {
    if (Test-Path $cp) { $configPath = $cp; break }
}

if (-not $configPath) {
    Write-Host "  WARNING: Claude Desktop config not found. Skipping." -ForegroundColor Yellow
} elseif (-not ((Get-Content $configPath -Raw) -match '"ipsa-power-system"')) {
    Write-Host "  ipsa-power-system not found in config -- already removed." -ForegroundColor Yellow
} else {
    try {
        $json = Get-Content $configPath -Raw -Encoding utf8 | ConvertFrom-Json
        $json.mcpServers.PSObject.Properties.Remove("ipsa-power-system")
        $utf8NoBom = New-Object System.Text.UTF8Encoding $false
        [System.IO.File]::WriteAllText($configPath, ($json | ConvertTo-Json -Depth 10), $utf8NoBom)
        Write-Host "  Done: ipsa-power-system removed from Claude Desktop config" -ForegroundColor Green
    } catch {
        Write-Host "  ERROR: Could not update config -- $_" -ForegroundColor Red
        Write-Host "  Please remove the ipsa-power-system entry manually from:" -ForegroundColor Yellow
        Write-Host "  $configPath" -ForegroundColor Yellow
    }
}

# ── Step 2: Delete install folder ─────────────────────────────
Write-Host "[2/2] Removing C:\ProgramData\IPSA_MCP\ ..." -ForegroundColor Yellow

# Stop any running MCP server process so locked .pyd files can be deleted
Get-Process -Name "python*" -ErrorAction SilentlyContinue |
    Where-Object { $_.MainWindowTitle -eq "" } |
    ForEach-Object {
        $cmdline = (Get-CimInstance Win32_Process -Filter "ProcessId=$($_.Id)" -ErrorAction SilentlyContinue).CommandLine
        if ($cmdline -like "*ipsa_mcp*") {
            Write-Host "  Stopping server process (PID $($_.Id))..." -ForegroundColor Yellow
            Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
            Start-Sleep -Milliseconds 500
        }
    }

$installPath = "C:\ProgramData\IPSA_MCP"
if (Test-Path $installPath) {
    try {
        Remove-Item $installPath -Recurse -Force -ErrorAction Stop
        Write-Host "  Done: $installPath deleted" -ForegroundColor Green
    } catch {
        Write-Host "  ERROR: Could not delete $installPath -- $_" -ForegroundColor Red
        Write-Host "  Please delete the folder manually." -ForegroundColor Yellow
    }
} else {
    Write-Host "  Folder not found -- already removed." -ForegroundColor Yellow
}

# ── Complete ───────────────────────────────────────────────────
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Uninstall complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Please restart Claude Desktop to apply changes." -ForegroundColor White
Write-Host ""
Read-Host "Press Enter to exit"
