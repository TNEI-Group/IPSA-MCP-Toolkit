========================================
  IPSA Power System MCP Server
  Version 2.0
========================================

This package connects Claude AI to IPSA 3 (Integrated Power System Analysis)
so you can analyse power networks using plain English.


REQUIREMENTS
------------
  - IPSA 3 must be installed on this machine (provides Python 3.11 + PyIPSA)
  - Claude Desktop (claude.ai/download)


INSTALLATION
------------
  1. Extract this ZIP to any folder
  2. Double-click  setup.bat
  3. When prompted, press Enter to exit
  4. Restart Claude Desktop
  5. Go to Settings > Developer and confirm "ipsa-power-system" shows RUNNING


UNINSTALLATION
--------------
  1. Double-click  uninstall.bat  (from the original ZIP folder)
  2. Restart Claude Desktop


WHAT YOU CAN DO
---------------
Open an IPSA network (.ipsa file) by telling Claude:

  "Load the network at C:\Projects\MyNetwork.ipsa"

Then ask questions or give instructions in plain English:


  LOAD FLOW & VOLTAGES
  --------------------
  "Run a load flow and show me all voltages"
  "Which busbars are below 0.95 pu?"
  "Show me branch loading — are any lines overloaded?"
  "What is the transformer loading on the 132/33 kV transformers?"
  "Show me the three-winding transformer results"

  FAULT LEVEL
  -----------
  "Run a fault level study and show me the highest fault currents"
  "Run an IEC 60909 fault level study"
  "Which busbars exceed 25 kA fault level?"

  GENERATION
  ----------
  "List all synchronous generators and their output"
  "Which generators are at reactive power limit?"

  LOADS
  -----
  "List all loads in the network"
  "Scale all loads by 1.2 (20% increase) and re-run load flow"
  "Scale the load at busbar HV-LOAD-01 by 0.8"
  "Restore the network to original load levels"

  BATTERIES (BESS)
  ----------------
  "Show me all battery storage units and their current output"

  SVCs / REACTIVE COMPENSATION
  ----------------------------
  "List all Static VAr Compensators and their reactive output"
  "Show all mechanically switched capacitors and their position"

  INDUCTION MACHINES
  ------------------
  "List all induction motors — which are running at high slip?"

  HARMONIC FILTERS
  ----------------
  "Show all harmonic filters and their tuning harmonics"

  NETWORK SUMMARY
  ---------------
  "Give me a summary of the network — total generation, load, losses"


AVAILABLE TOOLS (21)
--------------------
  tool_load_network            Load an IPSA network file
  tool_get_network_summary     Total generation, load, losses, island count
  tool_get_all_busbars         All busbar names and base voltages
  tool_run_load_flow           Execute balanced load flow
  tool_get_voltage_results     Per-busbar voltage magnitudes and angles
  tool_get_branch_loading      Branch MW, MVAr, loading %, losses
  tool_get_transformer_loading 2-winding transformer loading and tap positions
  tool_get_3w_transformer_loading  3-winding transformer winding flows
  tool_run_fault_level         Execute classical fault level study
  tool_get_fault_level_results Per-busbar fault currents (kA, MVA)
  tool_run_iec_fault_level     Execute IEC 60909 fault level study
  tool_get_iec_fault_results   IEC 60909 results: Ik'', peak, break currents
  tool_get_all_sync_machines   Synchronous generators — output and limits
  tool_get_all_loads           All loads — set-point and actual MW/MVAr
  tool_scale_loads             Scale all loads by a factor (from base case)
  tool_scale_single_load       Scale one named load by a factor
  tool_restore_network         Restore all loads to original base case values
  tool_get_all_grid_infeeds    Grid infeed (source) contributions
  tool_get_all_batteries       Battery storage units — output and voltage
  tool_get_all_static_vcs      SVCs — reactive output and limits
  tool_get_all_ind_machines    Induction motors — slip, efficiency, current
  tool_get_all_filters         Harmonic filters — type, tuning, size
  tool_get_all_mech_sw_caps    Mechanically switched capacitors/reactors


TROUBLESHOOTING
---------------
  Server not starting:
    - Check IPSA 3 is installed and licensed
    - Re-run setup.bat to reinstall

  "ipsa-power-system" shows ERROR in Claude Desktop:
    - Restart Claude Desktop after setup
    - Check C:\ProgramData\IPSA_MCP\ contains the server files

  Load flow does not converge:
    - Ask Claude: "Why might the load flow not converge?"
    - Check the network has a slack busbar (grid infeed) defined

  Wrong results after scaling loads:
    - Use "Restore the network to original load levels" before re-scaling
    - Load scaling always applies relative to the original base case


SUPPORT
-------
  Contact your IPSA administrator or the tool developer.

========================================
