# IPSA Power System MCP Server - Setup Script
# Run this once to set up the server for Claude Desktop
# Right-click this file and select "Run with PowerShell"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  IPSA MCP Server Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# ── Step 1: Find Python 3.11 ──────────────────────────────────
Write-Host "[1/5] Looking for Python 3.11..." -ForegroundColor Yellow

$python311Paths = @(
    "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
    "C:\Program Files\Python311\python.exe",
    "C:\Python311\python.exe"
)

$pythonPath = $null
foreach ($p in $python311Paths) {
    if (Test-Path $p) { $pythonPath = $p; break }
}

if (-not $pythonPath) {
    $defaultPython = (Get-Command python -ErrorAction SilentlyContinue).Path
    if ($defaultPython) {
        $ver = & $defaultPython --version 2>&1
        if ($ver -match "3\.11") { $pythonPath = $defaultPython }
    }
}

if (-not $pythonPath) {
    Write-Host "  ERROR: Python 3.11 not found." -ForegroundColor Red
    Write-Host "  Make sure IPSA 2 is installed on this machine." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "  Found: $pythonPath" -ForegroundColor Green

# ── Step 2: Create C:\ProgramData\IPSA_MCP\ ──────────────────
Write-Host "[2/5] Creating folder C:\ProgramData\IPSA_MCP\ ..." -ForegroundColor Yellow
$toolsPath = "C:\ProgramData\IPSA_MCP"
New-Item -ItemType Directory -Path $toolsPath -Force | Out-Null
Write-Host "  Done: $toolsPath" -ForegroundColor Green

# ── Step 3: Copy server files ─────────────────────────────────
Write-Host "[3/5] Copying server files..." -ForegroundColor Yellow
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$filesDir  = Join-Path $scriptDir "files"

if (-not (Test-Path $filesDir)) {
    Write-Host "  ERROR: 'files' folder not found next to setup.ps1" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# Stop any running server process so locked .pyd files can be replaced
Get-Process -Name "python*" -ErrorAction SilentlyContinue |
    Where-Object { $_.MainWindowTitle -eq "" } |
    ForEach-Object {
        $cmdline = (Get-CimInstance Win32_Process -Filter "ProcessId=$($_.Id)" -ErrorAction SilentlyContinue).CommandLine
        if ($cmdline -like "*ipsa_mcp*") {
            Write-Host "  Stopping existing server process (PID $($_.Id))..." -ForegroundColor Yellow
            Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
            Start-Sleep -Milliseconds 500
        }
    }

Copy-Item "$filesDir\*" $toolsPath -Force
Write-Host "  Done" -ForegroundColor Green

# ── Step 4: Install mcp library ───────────────────────────────
Write-Host "[4/5] Installing mcp library..." -ForegroundColor Yellow
& $pythonPath -m pip install mcp --quiet
Write-Host "  Done" -ForegroundColor Green

# ── Step 5: Update Claude Desktop config ──────────────────────
Write-Host "[5/5] Updating Claude Desktop config..." -ForegroundColor Yellow

$configPaths = @(
    "$env:LOCALAPPDATA\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Roaming\Claude\claude_desktop_config.json",
    "$env:APPDATA\Claude\claude_desktop_config.json"
)

$configPath = $null
foreach ($cp in $configPaths) {
    if (Test-Path $cp) { $configPath = $cp; break }
}

if (-not $configPath) {
    Write-Host "  WARNING: Claude Desktop config not found." -ForegroundColor Yellow
    Write-Host "  Please open Claude Desktop first, then re-run this setup." -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# Read existing config
$content = (Get-Content $configPath -Raw -Encoding utf8).Trim()

# Escape the python path for JSON
$escapedPython = $pythonPath -replace '\\', '\\\\'

# The IPSA entry as a JSON snippet
$ipsaEntry = "    `"ipsa-power-system`": {`n      `"command`": `"$escapedPython`",`n      `"args`": [`"C:\\\\ProgramData\\\\IPSA_MCP\\\\server_launcher.py`"]`n    }"

if ($content -match '"ipsa-power-system"') {
    # ── Case 1: Already installed ─────────────────────────────
    Write-Host "  ipsa-power-system already configured — no changes needed" -ForegroundColor Yellow

} elseif ($content -match '"mcpServers"') {
    # ── Case 2: mcpServers exists but no ipsa entry ───────────
    # Inject just the ipsa-power-system entry into the existing block.
    # Uses bracket counting to find the closing brace of mcpServers.

    $mcpIdx   = $content.IndexOf('"mcpServers"')
    $braceIdx = $content.IndexOf('{', $mcpIdx)

    # Walk forward counting braces to find the matching close
    $depth = 1
    $pos   = $braceIdx + 1
    while ($pos -lt $content.Length -and $depth -gt 0) {
        if     ($content[$pos] -eq '{') { $depth++ }
        elseif ($content[$pos] -eq '}') { $depth-- }
        if ($depth -gt 0) { $pos++ }
    }
    # $pos is now the index of the closing } of mcpServers

    # Check if the block is empty { }
    $innerContent = $content.Substring($braceIdx + 1, $pos - $braceIdx - 1).Trim()

    if ($innerContent -eq '') {
        # Empty mcpServers — insert as first entry
        $newContent = $content.Substring(0, $braceIdx + 1) +
                      "`n" + $ipsaEntry + "`n  " +
                      $content.Substring($pos)
    } else {
        # Non-empty mcpServers — append after last entry with a comma
        $newContent = $content.Substring(0, $pos) +
                      ",`n" + $ipsaEntry + "`n  " +
                      $content.Substring($pos)
    }

    $utf8NoBom = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::WriteAllText($configPath, $newContent, $utf8NoBom)
    Write-Host "  Done: ipsa-power-system added to existing mcpServers" -ForegroundColor Green

} else {
    # ── Case 3: No mcpServers at all — inject the full block ──
    $mcpBlock = ",`n  `"mcpServers`": {`n" + $ipsaEntry + "`n  }`n"
    $lastBrace = $content.LastIndexOf('}')
    $newContent = $content.Substring(0, $lastBrace) + $mcpBlock + "}"

    $utf8NoBom = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::WriteAllText($configPath, $newContent, $utf8NoBom)
    Write-Host "  Done: $configPath" -ForegroundColor Green
}

# ── Complete ──────────────────────────────────────────────────
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Setup complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor White
Write-Host "  1. Restart Claude Desktop" -ForegroundColor White
Write-Host "  2. Go to Settings > Developer" -ForegroundColor White
Write-Host "  3. Confirm 'ipsa-power-system' shows RUNNING" -ForegroundColor White
Write-Host ""
Read-Host "Press Enter to exit"
