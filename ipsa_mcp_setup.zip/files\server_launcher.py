import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ipsa_mcp_server

ipsa_mcp_server.main()
